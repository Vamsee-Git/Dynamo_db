import boto3
import json

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('user_data')
    
    try:
        http_method = event.get('httpMethod')
        
        if http_method == 'POST':
            body = json.loads(event['body'])
            user_id = body['user_id']
            user_data = body['user_data']
            
            table.put_item(
                Item={
                    'user_id': user_id,
                    'user_data': user_data
                }
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps('User added successfully!')
            }
        
        elif http_method == 'GET':
            user_id = event['queryStringParameters']['user_id']
            
            response = table.get_item(
                Key={
                    'user_id': user_id
                }
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps(response.get('Item', {}))
            }
        
        else:
            return {
                'statusCode': 400,
                'body': json.dumps('Unsupported HTTP method')
            }
    
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f'Missing key: {str(e)}')
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Internal server error: {str(e)}')
        }
