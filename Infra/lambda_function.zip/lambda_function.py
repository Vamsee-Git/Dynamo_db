import boto3
import json

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('user_data')
    
    if event['httpMethod'] == 'POST':
        body = json.loads(event['body'])
        user_id = body['user_id']
        user_data = body['user_data']
        
        table.put_item(
            Item={
                'user_id': user_id,
                'user_data': user_data
            }
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps('User added successfully!')
        }
    
    elif event['httpMethod'] == 'GET':
        user_id = event['queryStringParameters']['user_id']
        
        response = table.get_item(
            Key={
                'user_id': user_id
            }
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps(response.get('Item', {}))
        }
